var express = require("express");
var mongoose = require("mongoose");


mongoose.connect('mongodb://localhost/ktlss');

var db = mongoose.connection;
db.on('error', function() {
 console.log("error connecting mongo");
})

var schema = mongoose.Schema

var record = new schema({
 name: String,
 affiliation: String,
 indications:[
    String],
 country: String,
 LatLng: {
  Lat: Number,
  Long: Number
 }
}, {
 collection: 'plot'
})


var recordModel = mongoose.model('record', record)



var app = express()


app.use(function(req, res, next) {
 res.header("Access-Control-Allow-Origin", "*");
 res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
 next();
});


app.get('/', function(req, res) {

 recordModel.paginate(query, options).then(function(result) {
  var items = JSON.stringify(result);
  console.log(result)
  res.send(result)
 });

})

app.get('/ktl?', function(req, res, next) {
 console.log("HELOOOOOOOOOOOOOOOOOOOOOOOOOO")
 var query;

 if (req.query.name) {
  query = {
   name: req.query.name

  }
 } else if (req.query.country) {
  query = {
   country: req.query.country
  }
 } else if (req.query.affiliation) {
  query = {
   affiliation: req.query.affiliation
  }
 } else if (req.query.indications) {
  query = {
   indications: req.query.indications
  }
 } else if (req.query.id) {
  query = {
   _id: req.query.id
  }
 }
 //console.log(req.query.id);

 recordModel.find(query, function(err, result) {
  if (err) console.log(err)
  else {
   res.send(result)
  }
 })
})
app.get('/:id/connectedktls', function(req, res, next) {
console.log(req.params.id)

 var query = {
  _id: req.params.id
 }

 recordModel.find(query, "-_id", "indications", function(err, result) {
  if (err) 
console.log(err)
  else {
     
    var result = result[0]
 
    console.log(result.indications)

recordModel.aggregate([{
     $match: {
	
      $or: [{
	
       "country": result.country
      }, {
       "affiliation": result.affiliation
     }, {
    "indications":{$in:result.indications}
	
    }]
	
     }
	

    },
{
$limit:(21)
}
	
    ], function (err, result ) {
        if (err) {
            console.log(err);
        } else {
            res.json(result);
        }
    });

  }
 })

})

app.listen(3000, function() {
 console.log("The server seems to be running on port 3000")
})
console.log("hello world")
