var map = new google.maps.Map(d3.select("#map").node(), {
    zoom: 2,
    center: new google.maps.LatLng(50, -0.120850),
    
    mapTypeId: google.maps.MapTypeId.TERRAIN
/*
google.maps.event.addListener(map, 'zoom_changed', function() {
    zoomLevel = map.getZoom();
    if (zoomLevel >= minFTZoomLevel) {
        FTlayer.setMap(map);
    } else {
        FTlayer.setMap(null);
    }
});*/


});

var bhse;

$(document).ready(function() {

bhse = new Bloodhound({
  datumTokenizer: Bloodhound.tokenizers.whitespace,
  queryTokenizer: Bloodhound.tokenizers.whitespace,
  // `states` is an array of state names defined in "The Basics"
  local: names
});

$('#bloodhound .typeahead').typeahead({
  hint: true,
  highlight: true,
  minLength: 1
},
{
  name: 'states',
  source: bhse
}).on('typeahead:selected', function (obj, datum) {
    console.log(datum);
document.getElementById("name").value = datum
});})

var targetResult;
var overlay;

function plotmarker(resultDocs){
 var overlay = new google.maps.OverlayView();


    overlay.onAdd = function() {
        var layer = d3.select(this.getPanes().overlayMouseTarget).append("div")
            .attr("class", "stations");


        overlay.draw = function() {
            var projection = this.getProjection(),
                padding = 10;
        
        var tooltip = d3.select("body")
        .append("div")
        .attr("class", "tooltip")
        .style("opacity", 0);

            var marker = layer.selectAll("svg")
                .data(resultDocs)
                .each(transform)
                .enter().append("svg:svg")
                .each(transform)
                .attr("class", "marker");



            marker.append("svg:circle")
                .attr("r", 5)
                .attr("cx", padding)
                .attr("cy", padding)
        .on("mouseover", function(d) {
          tooltip.transition()
            .duration(200)
            .style("opacity", .9);
          tooltip.html('Name: '+d.name+'<br>'+'Affiliation: '+d.affiliation+'<br>'+'Country: '+d.country)
            .style("left", (d3.event.pageX + 5) + "px")
            .style("top", (d3.event.pageY - 28) + "px")
    document.getElementById('info').innerHTML = "INDICATIONS :"+d.indications+'<br>'+"NAME : "+d.name+'<br>'+"AFFILIATION :"+d.affiliation+'<br>'+"COUNTRY: "+d.country+'<br>'+"PHONE :"+d.phone+'<br>'+"LINK :"+d.link+'<br>'+"ADDRESS :"+d.address+'<br>'+"EMAIL :"+d.email+'<br>'+"LATITUDE :"+d.Lat+'<br>'+"LONGITUDE :"+d.Long;
          })
         .on("mouseout", function(d) {
          tooltip.transition()
          .duration(200)
          .style("opacity", 0);
      })
	.on("click", function(d) {
tooltip.transition()
          .duration(200)
          .style("opacity", 0);
          GetConnections(d._id);   
          })

            // Add a label.
            marker.append("svg:text")
                .attr("x", padding + 10)
                .attr("y", padding)
                .attr("dy", ".37em")
                .text(function(d) {
                    return d.name;
                });

            function transform(d) {

                d = new google.maps.LatLng(d.Lat, d.Long);
                d = projection.fromLatLngToDivPixel(d);

                return d3.select(this)
                    .style("left", (d.x - padding) + "px")
                    .style("top", (d.y - padding) + "px");
            }

        };
    };
    overlay.setMap(map);
};

// Load the hgdp data. When the data comes back, create an overlay.
function plotconnections(resultDocs) {
   
    overlay = new google.maps.OverlayView();


    overlay.onAdd = function() {
	var target={"Lat":targetResult[0].Lat, "Long":targetResult[0].Long};

    var layer = d3.select(this.getPanes().overlayMouseTarget)
        .append("div")
        .attr("height", "100%")
        .attr("width", "100%")
        .attr("class", "stations");
overlay.draw = function() {
  var radius = 5;
  var projection = this.getProjection(),
      padding = 10;


  var node_coord = {};

	var tooltip = d3.select("body")
        .append("div")
    	.attr("class", "tooltip")
    	.style("opacity", 0);

      var marker = layer.selectAll("svg")
      .data(resultDocs)
      .each(transform) // update existing markers
    .enter().append("svg:svg")
      .each(transform)
      .attr("class", "marker");
 marker.append("svg:circle")
      .attr("r", radius)
      .attr("cx", padding)
      .attr("cy", padding)
	.on("mouseover", function(d) {
          tooltip.transition()
            .duration(200)
            .style("opacity", .9);
          tooltip.html('Name: '+d.name+'<br>'+'Affiliation: '+d.affiliation+'<br>'+'Country: '+d.country)
            .style("left", (d3.event.pageX + 5) + "px")
            .style("top", (d3.event.pageY - 28) + "px")
	document.getElementById('info').innerHTML = "INDICATIONS :"+d.indications+'<br>'+"NAME : "+d.name+'<br>'+"AFFILIATION :"+d.affiliation+'<br>'+"COUNTRY: "+d.country+'<br>'+"PHONE :"+d.phone+'<br>'+"LINK :"+d.link+'<br>'+"ADDRESS :"+d.address+'<br>'+"EMAIL :"+d.email+'<br>'+"LATITUDE :"+d.Lat+'<br>'+"LONGITUDE :"+d.Long;
      	})
     	.on("mouseout", function(d) {
          tooltip.transition()
          .duration(200)
          .style("opacity", 0);
      });

  // Add a label.
  marker.append("svg:text")
      .attr("x", padding + 7)
      .attr("y", padding)
      .attr("dy", ".37em")
      .text(function(d) { return d.name; });


var markerLink = layer.selectAll(".links")
  .data(resultDocs)
  .each(pathTransform) // update existing markers       
.enter().append("svg:svg")
 .attr("class", "links")
  .each(pathTransform);
function pathTransform(d) {
        var t, b, l, r, w, h, currentSvg;
        $(this).empty(); // get rid of the old lines (cannot use d3 .remove() because i cannot use selectors after ... )

        dsrc = new google.maps.LatLng(d.Lat,d.Long);
        dtrg = new google.maps.LatLng(target.Lat,target.Long);
        d1 = projection.fromLatLngToDivPixel(dsrc);
        d2 = projection.fromLatLngToDivPixel(dtrg);
        if ( d1.y < d2.y ) {
            t = d1.y;
            b = d2.y;
        } else {
            t = d2.y;
            b = d1.y;
        }
        if ( d1.x < d2.x ) {
            l = d1.x;
            r = d2.x;
        } else {
            l = d2.x;
            r = d1.x; 
        }
        currentSvg = d3.select(this)

            .style("left", (l + radius) + "px")
            .style("top", (t + radius) + "px")
            .style("width", (r - l - radius) + "px")
            .style("height", (b - t - radius) + "px");
    // drawing the diagonal lines inside the svg elements. We could use 2 cases instead of for but maybe you will need to orient your graph (so you can use some arrows)
    if (( d1.y < d2.y) && ( d1.x < d2.x)) {
        currentSvg.append("svg:line")
            .style("stroke-width", 1)
            .style("stroke", "black")
            .attr("y1", 0)
            .attr("x1", 0)
            .attr("x2", r-l)
            .attr("y2", b-t);
        } else if ((d1.x > d2.x) && (d1.y > d2.y)){
        currentSvg.append("svg:line")
            .style("stroke-width", 1)
            .style("stroke", "black")
            .attr("y1", 0)
            .attr("x1", 0)
            .attr("x2", r-l)
            .attr("y2", b-t);
        } else if (( d1.y < d2.y) && ( d1.x > d2.x)){
            currentSvg.append("svg:line")
                .style("stroke-width", 1)
                .style("stroke", "black")
                .attr("y1", 0)
                .attr("x2", 0)
                .attr("x1", r-l)
                .attr("y2", b-t);
            } else if ((d1.x < d2.x) && (d1.y > d2.y)){
            currentSvg.append("svg:line")
                .style("stroke-width", 1)
                .style("stroke", "black")
                .attr("y1", 0)
                .attr("x2", 0)
                .attr("x1", r-l)
                .attr("y2", b-t);
            } else {
            console.log("something is wrong!!!");
            }


        return currentSvg;
  } 
function transform(d,i) {
      console.log(i);
            node_coord[i + "," + 0] = d.Long;
            node_coord[i + "," + 1] = d.Lat;

        d = new google.maps.LatLng(d.Lat, d.Long);
        d = projection.fromLatLngToDivPixel(d);

        return d3.select(this)
            .style("left", (d.x - padding) + "px")
            .style("top", (d.y - padding) + "px");
      }
layer.append("div")
     .attr("class", "stations.line");

    };

  };
    overlay.setMap(map);
};


var search = function() {
    clearTable();
    var val = filter.value;
    var value = document.getElementById("name").value;
    var table = document.getElementById("datatable");

    $.get({
        url: "http://localhost:3000/ktl?" + val + "=" + value,

        success: function(data) {
   	targetResult = data;
            for (var i = 0; i < data.length; i++) {
                var row = table.insertRow();
                var cell1 = row.insertCell(0);
                var cell2 = row.insertCell(1);
                cell1.innerHTML = data[i].name;
                cell2.innerHTML = data[i]._id;
            }
            plotmarker(data);
        }
        // document.getElementById('info').innerHTML = JSON.stringify(data);
    });
}

var GetConnections = function(value) {
    clearTable();
   
    var val = filter.value;
    if(value)
	filter.value=value
    $.get({
        url: "http://localhost:3000/"+ value+"/connectedktls",

        success: function(data) {
   	
            plotconnections(data);
	    //Clear();
        }
        // document.getElementById('info').innerHTML = JSON.stringify(data);



    });
}

var clearTable = function() {
	 //var table = document.getElementById("datatable");
	$("#datatable tr").remove();

	d3.selectAll("svg").remove();
}

var selectChanged = function(){
bhse.clear();
if(document.getElementById("filter").value==="name"){
bhse.local = names
}
else if(document.getElementById("filter").value==="country")
bhse.local = country
else if(document.getElementById("filter").value==="affiliation")
bhse.local = affiliation
else if(document.getElementById("filter").value==="indications")
bhse.local = indications

bhse.initialize(true);
}

var names = [	"Kristi Le",
	"Lilly Phelps",
	"Elvia Shannon",
	"Esther Rosales",
	"Simpson Whitney",
	"Sims Lopez",
	"Pearl Lynch",
	"Francis Bright",
	"Sharlene Buck",
	"Perkins Shaw",
	"Guadalupe Clements",
	"Jennifer Underwood",
	"Pate Huff",
	"Ines Estes",
	"Neal Pena",
	"Sasha Wyatt",
	"Augusta Waller",
	"Shaffer Mcconnell",
	"Odonnell Chandler",
	"Powell Jordan",
	"Kathleen Miranda",
	"Renee Hess",
	"Slater Mcdaniel",
	"Stella Richards",
	"Hollie Nichols",
	"Hilary Trujillo",
	"Marlene Whitehead",
	"Morin Potter",
	"Paul Kaufman",
	"Earlene Cash",
	"Chen Gates",
	"Lynnette Bean",
	"Mattie Brooks",
	"Rosella Leblanc",
	"Tamera Bishop",
	"Nona Stevenson",
	"Anna Chase",
	"Mills House",
	"Julianne Head",
	"Tate Pickett",
	"Millie Kelley",
	"Barber Ayers",
	"Gay Warner",
	"Simmons Short",
	"Ola Mercado",
	"Carol Duke",
	"Faulkner Chen",
	"Penny Browning",
	"Conley Rosario",
	"Orr Gutierrez",
	"Annabelle Kinney",
	"Lucile Gilmore",
	"Atkins Weeks",
	"Autumn Franks",
	"Evangelina Richardson",
	"Hawkins Kane",
	"Rae Snow",
	"Alvarez Fields",
	"Amy Leon",
	"Chandra Hale",
	"Bonner Puckett",
	"Elma Becker",
	"Ochoa Ross",
	"Alexander Frank",
	"Monica Clay",
	"Warren Cabrera",
	"Kaitlin Wilcox",
	"Sanchez Hewitt",
	"Audrey Woods",
	"Melba Burnett",
	"Trevino Benjamin",
	"Cline Landry",
	"Lola Jacobson",
	"Acosta Hogan",
	"Ursula Vaughan",
	"Joyner Downs",
	"Jewel Stuart",
	"Natalie Thompson",
	"Moore Sloan",
	"Bernadette Carson",
	"Weber Reid",
	"Christina Sharp",
	"Conway Grant",
	"Tanisha Boyle",
	"James Wolf",
	"Clark Haney",
	"Campos Holland",
	"Kerry Kirk",
	"Snider Cantu",
	"Daniels Mays",
	"Maura Sandoval",
	"Bray Barnett",
	"Rasmussen Wiggins",
	"Louisa Carroll",
	"Vivian Ratliff",
	"Jackie Kline",
	"Lorena Crawford",
	"Dodson Moon",
	"Shirley Reilly",
	"Cotton Byrd",
	"Sherrie Byers",
	"Lucinda Hamilton",
	"Bonita Schroeder",
	"Georgina Wagner",
	"Johnston Strickland",
	"Joanne Hickman",
	"Jeanette Case",
	"Mayer Brown",
	"Burns Oconnor",
	"Lillie Macias",
	"Lou Gordon",
	"Jan Sargent",
	"Sandra Rush",
	"Marsh Martin",
	"Randi Dillon",
	"Huber Fischer",
	"Barr Christian",
	"Rivers Taylor",
	"Berg Kelly",
	"Levy Silva",
	"Coleman Salas",
	"Lucia Sears",
	"Sheri Mercer",
	"Tami Rose",
	"Savannah Petersen",
	"Crosby Maxwell",
	"Cochran Huffman",
	"Odessa Gillespie",
	"Daniel Camacho",
	"Wilson Hampton",
	"Peggy Palmer",
	"Stacie Rodriguez",
	"Eunice Everett",
	"Tricia Cain",
	"Brooks Langley",
	"Nanette Sharpe",
	"Knox Middleton",
	"Baxter Boyer",
	"Teri Mccray",
	"Delores Compton",
	"Ryan Lowe",
	"White Padilla",
	"Holt Stout",
	"Toni Mosley",
	"Julie Sheppard",
	"Lee Knight",
	"Minerva Dickson",
	"Lenora Henry",
	"Shari Vega",
	"Kate Espinoza",
	"Mcintosh Hopper",
	"Callie Stevens",
	"Colon Rhodes",
	"Sosa Henderson",
	"Delgado Wiley",
	"Burch Adkins",
	"Cooper Gilbert",
	"Witt Gardner",
	"Carrie Maynard",
	"Evans Leach",
	"Lavonne Bruce",
	"Vega Callahan",
	"Pearson Miller",
	"Gardner Golden",
	"Pena Duffy",
	"Walsh Raymond",
	"Kane Moses",
	"Lynn Glenn",
	"Osborn Walter",
	"Hayes Sullivan",
	"Darcy Knowles",
	"Schultz Pierce",
	"Farmer Bush",
	"Laverne Allen",
	"Althea Bentley",
	"Bridgette Mccall",
	"Yesenia Hendrix",
	"Samantha Edwards",
	"Velez Holmes",
	"Robertson Cobb",
	"Claudette Wells",
	"Lottie Hurst",
	"Riddle Bolton",
	"Angelia Hebert",
	"Iris Jarvis",
	"Terry Roman",
	"Rogers Spencer",
	"Viola Fisher",
	"Workman Mcleod",
	"Traci Ware",
	"Cornelia Patterson",
	"Jackson Marshall",
	"Georgia Daugherty",
	"Beatriz Levine",
	"Reyes Gibbs",
	"Lorene Acosta",
	"Celina Donovan",
	"Oconnor Contreras",
	"Jodi Brock",
	"Janelle Watts"
];
var affiliation =
[
	"University of Svalbard and Jan Mayen Islands",
	"University of Saint Lucia",
	"University of Syria",
	"University of Cayman Islands",
	"University of Djibouti",
	"University of Brunei Darussalam",
	"University of Saint Vincent and The Grenadines",
	"University of Hungary",
	"University of Norway",
	"University of Papua New Guinea",
	"University of Western Sahara",
	"University of Kyrgyzstan",
	"University of Norfolk Island",
	"University of Pitcairn",
	"University of Korea (South)",
	"University of Hong Kong",
	"University of Mayotte",
	"University of Bouvet Island",
	"University of Taiwan",
	"University of Andorra",
	"University of United States",
	"University of Togo",
	"University of Portugal",
	"University of Finland",
	"University of Greenland",
	"University of Niue",
	"University of Iraq",
	"University of Antarctica",
	"University of Iceland",
	"University of Lesotho",
	"University of Reunion",
	"University of Micronesia",
	"University of Bahrain",
	"University of Benin",
	"University of Mongolia",
	"University of Mali",
	"University of France, Metropolitan",
	"University of Italy",
	"University of Equatorial Guinea",
	"University of Uruguay",
	"University of Samoa",
	"University of Aruba",
	"University of Senegal",
	"University of United Arab Emirates",
	"University of Austria",
	"University of Indonesia",
	"University of Qatar",
	"University of Sri Lanka",
	"University of Sierra Leone",
	"University of Colombia",
	"University of Tonga",
	"University of Saint Kitts and Nevis",
	"University of Antigua and Barbuda",
	"University of Sao Tome and Principe",
	"University of Puerto Rico",
	"University of Brazil",
	"University of Greece",
	"University of Comoros",
	"University of East Timor",
	"University of Korea (North)",
	"University of Spain",
	"University of Kuwait",
	"University of Slovak Republic",
	"University of Cameroon",
	"University of Jamaica",
	"University of Grenada",
	"University of Bolivia",
	"University of Netherlands Antilles",
	"University of Faroe Islands",
	"University of Swaziland",
	"University of Solomon Islands",
	"University of Denmark",
	"University of Mauritius",
	"University of Anguilla",
	"University of Ghana",
	"University of Switzerland",
	"University of Guinea",
	"University of Dominican Republic",
	"University of Paraguay",
	"University of Central African Republic",
	"University of Turkey",
	"University of Belgium",
	"University of Panama",
	"University of Namibia",
	"University of Latvia",
	"University of Northern Mariana Islands",
	"University of Chile",
	"University of Wallis and Futuna Islands",
	"University of Falkland Islands (Malvinas)",
	"University of Fiji",
	"University of Algeria",
	"University of Congo",
	"University of Tokelau",
	"University of Rwanda",
	"University of India",
	"University of New Zealand",
	"University of Ethiopia",
	"University of Zambia",
	"University of Myanmar",
	"University of Mauritania",
	"University of St. Helena",
	"University of Eritrea",
	"University of Montserrat",
	"University of San Marino",
	"University of Gambia",
	"University of Bulgaria",
	"University of Israel",
	"University of Cocos (Keeling Islands)",
	"University of Guatemala",
	"University of Saudi Arabia",
	"University of Kenya",
	"University of Bermuda",
	"University of Ecuador",
	"University of Virgin Islands (British)",
	"University of Mexico",
	"University of Cote D'Ivoire (Ivory Coast)",
	"University of Niger",
	"University of Viet Nam",
	"University of Turks and Caicos Islands"
];
var country =
[
	"Czech Republic",
	"India",
	"France",
	"Switzerland",
	"New Zealand",
	"Finland",
	"Cambodia",
	"Singapore",
	"Iceland",
	"Romania",
	"Brazil",
	"Japan",
	"Estonia",
	"Greece",
	"Spain",
	"Jamaica",
	"Uganda",
	"Philippines",
	"Hong Kong",
	"Austria",
	"South Africa",
	"Chile",
	"Ukraine",
	"Ireland",
	"Turkey",
	"Canada",
	"United Arab Emirates",
	"Denmark",
	"Bulgaria",
	"Egypt",
	"Nigeria",
	"Zimbabwe",
	"Honduras",
	"Italy",
	"Belgium",
	"China",
	"Jordan",
	"Georgia",
	"Portugal",
	"Slovakia",
	"Hungary",
	"Poland",
	"Cyprus",
	"Sri Lanka",
	"Swaziland",
	"Israel",
	"Australia",
	"Sweden",
	"Vietnam",
	"Indonesia",
	"Croatia",
	"Uruguay",
	"United States Of America",
	"Bermuda",
	"Serbia",
	"Argentina",
	"Russia",
	"Sudan",
	"Germany",
	"Venezuela"
];
var indications = 
[
	"Brain Cancer",
	"Breast Cancer",
	"Cervical Cancer",
	"Colorectal Cancer",
	"Lymphoma",
	"Pancreatic Cancer",
	"Prostate Cancer",
	"Skin Cancer",
	"Cholangiocarcinoma",
	"Neuroblastoma",
	"Thyroid Cancer",
	"Bone Marrow Cancer",
	"Gastrointestinal Stromal Tumor",
	"Lung Cancer",
	"Kidney Cancer",
	"Ovarian Cancer",
	"Gastric Cancer",
	"Hematological Malignancies",
	"Solid Tumor",
	"Multiple Myeloma",
	"Adrenal Cancer",
	"Miscellaneous",
	"Head and Neck Cancer"
];

